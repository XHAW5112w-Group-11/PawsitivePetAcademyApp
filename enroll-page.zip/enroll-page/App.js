import React, { useState } from 'react';
import { 
  StyleSheet, 
  Text, 
  View, 
  TextInput, 
  TouchableOpacity, 
  ScrollView, 
  SafeAreaView, 
  Alert,
  KeyboardAvoidingView,
  Platform
} from 'react-native';

// Mock Course Data
const COURSES = [
  { id: '1', name: 'Canine Obedience Training', fee: '\R1500' },
  { id: '2', name: 'Animal Behaviour', fee: '\R1500' },
  { id: '3', name: 'Pet Grooming', fee: '\R1500' },
  { id: '4', name: 'Pet Business Management', fee: '\R1500' },
  { id: '5', name: 'Puppy Care', fee: '\R750'},
  { id: '6', name: 'Pet First Aid', fee: '\R750'},
  { id: '7', name: 'Basic Dog Walking', fee: '\R750'},
];

export default function App() {
  // Form State
  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    phone: '',
    selectedCourse: null,
  });

  // Simple Input Handlers
  const updateField = (field, value) => {
    setFormData({ ...formData, [field]: value });
  };

  // Step Validation & Navigation
  const handleNextStep = () => {
    if (currentStep === 1) {
      if (!formData.fullName.trim() || !formData.email.trim() || !formData.phone.trim()) {
        Alert.alert('Missing Info', 'Please fill out all personal details.');
        return;
      }
      if (!formData.email.includes('@')) {
        Alert.alert('Invalid Email', 'Please enter a valid email address.');
        return;
      }
      setCurrentStep(2);
    }
  };

  const handleSubmit = () => {
    if (!formData.selectedCourse) {
      Alert.alert('Selection Required', 'Please select a course to complete enrollment.');
      return;
    }
    
    // Final Success Callback
    Alert.alert(
      '🎉 Enrollment Successful!', 
      `Thank you, ${formData.fullName}.\nYou have successfully enrolled in: ${formData.selectedCourse.name}. Check your email for next steps.`,
      [{ text: 'Reset Form', onPress: resetForm }]
    );
  };

  const resetForm = () => {
    setFormData({ fullName: '', email: '', phone: '', selectedCourse: null });
    setCurrentStep(1);
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <KeyboardAvoidingView 
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'} 
        style={styles.container}
      >
        <ScrollView contentContainerStyle={styles.scrollContainer}>
          
          {/* Header */}
          <View style={styles.header}>
            <Text style={styles.headerTitle}>Course Enrollment</Text>
            <Text style={styles.headerSubtitle}>Secure your spot in seconds</Text>
          </View>

          {/* Progress Indicator */}
          <View style={styles.progressContainer}>
            <View style={[styles.progressBar, { width: currentStep === 1 ? '50%' : '100%' }]} />
            <Text style={styles.progressText}>Step {currentStep} of 2</Text>
          </View>

          {/* Step 1: Personal Information */}
          {currentStep === 1 && (
            <View style={styles.card}>
              <Text style={styles.sectionTitle}>Personal Details</Text>
              
              <Text style={styles.label}>Full Name</Text>
              <TextInput 
                style={styles.input}
                placeholder="John Doe"
                placeholderTextColor="#999"
                value={formData.fullName}
                onChangeText={(val) => updateField('fullName', val)}
              />

              <Text style={styles.label}>Email Address</Text>
              <TextInput 
                style={styles.input}
                placeholder="johndoe@example.com"
                placeholderTextColor="#999"
                keyboardType="email-address"
                autoCapitalize="none"
                value={formData.email}
                onChangeText={(val) => updateField('email', val)}
              />

              <Text style={styles.label}>Phone Number</Text>
              <TextInput 
                style={styles.input}
                placeholder="+27 82 123 4567"
                placeholderTextColor="#999"
                keyboardType="phone-pad"
                value={formData.phone}
                onChangeText={(val) => updateField('phone', val)}
              />

              <TouchableOpacity style={styles.primaryButton} onPress={handleNextStep}>
                <Text style={styles.buttonText}>Choose Course →</Text>
              </TouchableOpacity>
            </View>
          )}

          {/* Step 2: Course Selection */}
          {currentStep === 2 && (
            <View style={styles.card}>
              <Text style={styles.sectionTitle}>Select Your Program</Text>
              
              {COURSES.map((course) => {
                const isSelected = formData.selectedCourse?.id === course.id;
                return (
                  <TouchableOpacity 
                    key={course.id}
                    style={[styles.courseOption, isSelected && styles.courseOptionSelected]}
                    onPress={() => updateField('selectedCourse', course)}
                  >
                    <View style={styles.courseInfo}>
                      <Text style={[styles.courseName, isSelected && styles.textWhite]}>
                        {course.name}
                      </Text>
                      <Text style={[styles.courseFee, isSelected && styles.textWhiteDetails]}>
                        Tuition: {course.fee}
                      </Text>
                    </View>
                    <View style={[styles.radioCircle, isSelected && styles.radioCircleSelected]}>
                      {isSelected && <View style={styles.radioInnerCircle} />}
                    </View>
                  </TouchableOpacity>
                );
              })}

              {/* Navigation Action Buttons */}
              <View style={styles.buttonRow}>
                <TouchableOpacity 
                  style={styles.secondaryButton} 
                  onPress={() => setCurrentStep(1)}
                >
                  <Text style={styles.secondaryButtonText}>Back</Text>
                </TouchableOpacity>

                <TouchableOpacity 
                  style={[styles.primaryButton, { flex: 2, marginTop: 0 }]} 
                  onPress={handleSubmit}
                >
                  <Text style={styles.buttonText}>Complete Enrollment</Text>
                </TouchableOpacity>
              </View>
            </View>
          )}

        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

// Styling Sheet
const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: '#735477' },
  container: { flex: 1 },
  scrollContainer: { padding: 24, justifyContent: 'center' },
  header: { marginBottom: 24, alignItems: 'center' },
  headerTitle: { fontSize: 28, fontWeight: 'bold', color: '#ffffff', marginBottom: 4 },
  headerSubtitle: { fontSize: 16, color: '#ffffff' },
  progressContainer: { height: 6, backgroundColor: '#078B88', borderRadius: 3, marginBottom: 24, overflow: 'hidden', position: 'relative' },
  progressBar: { height: '100%', backgroundColor: '#d9a32e' },
  progressText: { fontSize: 12, fontWeight: '600', color: '#ffffff', textAlign: 'right', marginTop: 8 },
  card: { backgroundColor: '#ffffff', borderRadius: 16, padding: 24, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.05, shadowRadius: 15, elevation: 2 },
  sectionTitle: { fontSize: 20, fontWeight: '700', color: '#0f172a', marginBottom: 20 },
  label: { fontSize: 14, fontWeight: '600', color: '#475569', marginBottom: 6 },
  input: { backgroundColor: '#f1f5f9', borderWidth: 1, borderColor: '#e2e8f0', borderRadius: 8, padding: 14, fontSize: 16, color: '#1e293b', marginBottom: 18 },
  primaryButton: { backgroundColor: '#d9a32e', borderRadius: 8, padding: 16, alignItems: 'center', marginTop: 8 },
  buttonText: { color: '#ffffff', fontSize: 16, fontWeight: '600' },
  courseOption: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 16, borderWidth: 1, borderColor: '#e2e8f0', borderRadius: 10, marginBottom: 12, backgroundColor: '#ffffff' },
  courseOptionSelected: { backgroundColor: '#735477', borderColor: '#735477' },
  courseInfo: { flex: 1, paddingRight: 10 },
  courseName: { fontSize: 16, fontWeight: '600', color: '#1e293b', marginBottom: 4 },
  courseFee: { fontSize: 14, color: '#64748b' },
  textWhite: { color: '#ffffff' },
  textWhiteDetails: { color: '#c7d2fe' },
  radioCircle: { width: 20, height: 20, borderRadius: 10, borderWidth: 2, borderColor: '#cbd5e1', alignItems: 'center', justifyContent: 'center' },
  radioCircleSelected: { borderColor: '#ffffff' },
  radioInnerCircle: { width: 10, height: 10, borderRadius: 5, backgroundColor: '#ffffff' },
  buttonRow: { flexDirection: 'row', gap: 12, marginTop: 16, alignItems: 'center' },
  secondaryButton: { flex: 1, borderHeight: 1, borderWidth: 1, borderColor: '#cbd5e1', borderRadius: 8, padding: 16, alignItems: 'center' },
  secondaryButtonText: { color: '#078B88', fontSize: 16, fontWeight: '600' }
});
