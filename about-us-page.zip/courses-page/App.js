import React from 'react';
import { StyleSheet, Text, View, Image, ScrollView, TouchableOpacity, Linking } from 'react-native';

export default function App() {
  return (
    <ScrollView style={styles.container}>
      {/* Header Banner */}
      <View style={styles.header}>
        <Text style={styles.companyName}>Pawsitive Pet Academy</Text>
        <Text style={styles.tagline}>Pet training academy</Text>
      </View>

      {/* About Content */}
      <View style={styles.contentBody}>
        <Text style={styles.sectionTitle}>Our Mission and Philosophy</Text>
        <Text style={styles.bodyText}>
          Empowering dogs and their owners through positive reinforcement, force-free training methods, and science-backed to build lifelong bonds built on trust, respect and clear communication.
        </Text>

        <Text style={styles.sectionTitle}>Meet Our Trainers</Text>
        <Text style={styles.bodyText}>
          Maria, Julia, Sarah, George, Lucy, Damian, John, Diana, Scott, Jason, Suzanne and William.
        </Text>

        {/* Contact CTA */}
        <TouchableOpacity 
          style={styles.button} 
          onPress={() => Linking.openURL('https://github.com/XHAW5112w-Group-11/PawsitivePetAcademyApp')}
        >
          <Text style={styles.buttonText}>Visit Our Website</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#735477',
  },
  header: {
    padding: 40,
    alignItems: 'center',
    justifyContent: 'center',
  },
  companyName: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#ffffff',
    marginBottom: 8,
  },
  tagline: {
    fontSize: 16,
    color: '#D9A32E',
    textAlign: 'center',
  },
  contentBody: {
    padding: 24,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: '#FFFFFF',
    marginTop: 24,
    marginBottom: 8,
  },
  bodyText: {
    fontSize: 15,
    lineHeight: 24,
    color: '#FFFFFF',
  },
  button: {
    backgroundColor: '#078B88',
    paddingVertical: 14,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 32,
  },
  buttonText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: '600',
  },
});
