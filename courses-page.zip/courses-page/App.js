import React from 'react';
import { StyleSheet, Text, View, ScrollView, TouchableOpacity } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

// Course data including the details from your Figma wireframes
const courses = {
  sixWeeks: [
    { id: '1', title: 'Basic Dog Walking', price: 'R750', purpose: 'To teach professional and safe dog walking practices.', content: 'Walking equipment, Handling multiple dogs, Safety procedures, Exercise routines' },
    { id: '2', title: 'Puppy Care', price: 'R750', purpose: 'To provide new puppy owners with essential care knowledge.', content: 'Feeding, Vaccinations, Toilet training, Exercise, Socialisation' },
    { id: '3', title: 'Pet First Aid', price: 'R750', purpose: 'To provide emergency first aid knowledge for pets.', content: 'CPR, Minor injuries, Poison awareness, heatstroke and emergency transport' },
  ],
  sixMonths: [
    { id: '4', title: 'Animal Behaviour', price: 'R1500', purpose: 'To understand common pet behaviours and improve communication with animals.', content: 'Animal psychology, Reading body language, Stress management, Behaviour modification, Enrichment activities' },
    { id: '5', title: 'Pet Grooming', price: 'R1500', purpose: 'To provide professional grooming skills for domestic pets.', content: 'Coat care, Bathing techniques, Nail trimming, Ear and eye cleaning, Grooming equipment' },
    { id: '6', title: 'Pet Business Management', price: 'R1500', purpose: 'To prepare learners to operate a successful pet-related business.', content: 'Customer service, Marketing, Business planning, Financial management, Legal requirements' },
    { id: '7', title: 'Canine Obedience Training', price: 'R1500', purpose: 'To teach effective dog obedience and behaviourial training techniques.', content: 'Basic commands, Leash training, Behaviour correction, Positive reinforcement, Socialisation techniques' }
  ]
};

const CourseCard = ({ course, navigation }) => (
  <View style={styles.card}>
    <View style={styles.cardHeader}>
      <Text style={styles.cardTitle}>{course.title}</Text>
      <Text style={styles.cardPrice}>{course.price}</Text>
    </View>
    <TouchableOpacity 
      style={styles.button}
      onPress={() => navigation.navigate('CourseDetail', { course })}
    >
      <Text style={styles.buttonText}>View Details</Text>
    </TouchableOpacity>
  </View>
);

const CourseListScreen = ({ navigation }) => (
  <ScrollView style={styles.container}>
    <View style={styles.header}>
      <Text style={styles.headerTitle}>Training Courses</Text>
    </View>

    <View style={styles.section}>
      <Text style={styles.sectionTitle}>6-Week Courses</Text>
      {courses.sixWeeks.map(course => (
        <CourseCard key={course.id} course={course} navigation={navigation} />
      ))}
    </View>

    <View style={styles.section}>
      <Text style={styles.sectionTitle}>6-Month Courses</Text>
      {courses.sixMonths.map(course => (
        <CourseCard key={course.id} course={course} navigation={navigation} />
      ))}
    </View>
  </ScrollView>
);

const CourseDetailScreen = ({ route }) => {
  const { course } = route.params;
  return (
    <View style={styles.detailContainer}>
      <Text style={styles.detailTitle}>{course.title}</Text>
      <Text style={styles.detailPrice}>Course Fees: {course.price}</Text>
      
      <View style={styles.detailContentBox}>
        <Text style={styles.detailHeading}>Purpose:</Text>
        <Text style={styles.detailText}>{course.purpose}</Text>
        
        <Text style={[styles.detailHeading, { marginTop: 24 }]}>Content:</Text>
        <Text style={styles.detailText}>{course.content}</Text>
      </View>
    </View>
  );
};

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen 
          name="CourseList" 
          component={CourseListScreen} 
          options={{ 
            title: 'Courses', 
            headerStyle: { backgroundColor: '#078B88' }, 
            headerTintColor: '#fff' 
          }} 
        />
        <Stack.Screen 
          name="CourseDetail" 
          component={CourseDetailScreen} 
          options={{ 
            title: 'Course Info', 
            headerStyle: { backgroundColor: '#078B88' }, 
            headerTintColor: '#fff' 
          }} 
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#078B88',
  },
  header: {
    padding: 24,
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: '#fff',
    alignItems: 'center',
    marginBottom: 16,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0B2947',
  },
  section: {
    paddingHorizontal: 16,
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#0B2947', 
    marginBottom: 12,
  },
  card: {
    backgroundColor: '#fff',
    padding: 16,
    borderRadius: 8,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  cardTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#0B2947',
    flex: 1,
  },
  cardPrice: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#D9A32E',
  },
  button: {
    backgroundColor: '#D9A32E',
    paddingVertical: 10,
    borderRadius: 8,
    alignItems: 'center',
  },
  buttonText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 14,
  },
  // Detail Screen Styles
  detailContainer: {
    flex: 1,
    backgroundColor: '#078B88', // Teal blue background from Figma
    padding: 24,
  },
  detailTitle: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#fff',
    marginBottom: 8,
  },
  detailPrice: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#D9A32E',
    marginBottom: 32,
  },
  detailContentBox: {
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    padding: 20,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.1)',
  },
  detailHeading: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#D9A32E',
    marginBottom: 8,
  },
  detailText: {
    fontSize: 16,
    color: '#F5F5F5',
    lineHeight: 26,
  }
});