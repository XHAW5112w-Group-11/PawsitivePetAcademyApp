import React, { useState } from 'react';
import {
  StyleSheet,
  Text,
  View,
  TextInput,
  TouchableOpacity,
  ScrollView,
  Image,
  Alert,
  StatusBar,
  KeyboardAvoidingView,
  Platform,
  Modal,
} from 'react-native';

export default function App() {
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [subject, setSubject] = useState('General Enquiry');
  const [message, setMessage] = useState('');
  const [modalVisible, setModalVisible] = useState(false);
  const [modalMessage, setModalMessage] = useState('');

  const subjects = [
    'General Enquiry',
    'Course Information',
    'Fees & Registration',
    'Private Training Session',
  ];

  const handleSubmit = () => {
    if (!fullName.trim() || !email.trim() || !message.trim()) {
      Alert.alert('Missing Information', 'Please complete all required fields (*).');
      return;
    }

    setModalMessage(
      `Thank you ${fullName}! Your enquiry regarding "${subject}" was sent successfully to Pawsitive Pet Academy.`
    );
    setModalVisible(true);
  };

  const resetForm = () => {
    setModalVisible(false);
    setFullName('');
    setEmail('');
    setSubject('General Enquiry');
    setMessage('');
  };

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      style={styles.container}
    >
      <StatusBar barStyle="light-content" backgroundColor="#007A78" />

      {/* Header with Brand Palette */}
      <View style={styles.header}>
        <View style={styles.logoBadge}>
          <Image
            source={{
              uri: 'https://images.unsplash.com/photo-1543466835-00a7907e9de1?auto=format&fit=crop&w=200&q=80',
            }}
            style={styles.logoImage}
          />
        </View>
        <Text style={styles.brandTitle}>PAWSITIVE PET ACADEMY</Text>
        <Text style={styles.tagline}>
          Train with kindness. Grow with confidence.
        </Text>
      </View>

      <ScrollView
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        {/* Page Title */}
        <View style={styles.titleSection}>
          <Text style={styles.mainTitle}>Contact the Academy</Text>
          <Text style={styles.subtitle}>
            Send an enquiry using the demonstration form below. We'd love to hear from you!
          </Text>
        </View>

        {/* Info Cards */}
        <View style={styles.infoRow}>
          <View style={styles.infoCard}>
            <Text style={styles.infoIcon}>📍</Text>
            <Text style={styles.infoTitle}>Location</Text>
            <Text style={styles.infoValue}>Durban, South Africa</Text>
          </View>

          <View style={styles.infoCard}>
            <Text style={styles.infoIcon}>✉️</Text>
            <Text style={styles.infoTitle}>Email & Phone</Text>
            <Text style={styles.infoValue}>info@pawsitive.co.za</Text>
          </View>
        </View>

        {/* Contact Form Card */}
        <View style={styles.formCard}>
          <Text style={styles.formHeader}>Send an Enquiry</Text>

          {/* Full Name */}
          <View style={styles.inputGroup}>
            <Text style={styles.label}>
              Full Name <Text style={styles.required}>*</Text>
            </Text>
            <TextInput
              style={styles.input}
              placeholder="e.g. Jane Doe"
              placeholderTextColor="#8F9B9D"
              value={fullName}
              onChangeText={setFullName}
            />
          </View>

          {/* Email Address */}
          <View style={styles.inputGroup}>
            <Text style={styles.label}>
              Email Address <Text style={styles.required}>*</Text>
            </Text>
            <TextInput
              style={styles.input}
              placeholder="you@example.com"
              placeholderTextColor="#8F9B9D"
              keyboardType="email-address"
              autoCapitalize="none"
              value={email}
              onChangeText={setEmail}
            />
          </View>

          {/* Subject Selection */}
          <View style={styles.inputGroup}>
            <Text style={styles.label}>Subject</Text>
            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              style={styles.pillScrollView}
            >
              {subjects.map((item) => (
                <TouchableOpacity
                  key={item}
                  style={[
                    styles.pill,
                    subject === item && styles.pillActive,
                  ]}
                  onPress={() => setSubject(item)}
                >
                  <Text
                    style={[
                      styles.pillText,
                      subject === item && styles.pillTextActive,
                    ]}
                  >
                    {item}
                  </Text>
                </TouchableOpacity>
              ))}
            </ScrollView>
          </View>

          {/* Message */}
          <View style={styles.inputGroup}>
            <Text style={styles.label}>
              How can we help? <Text style={styles.required}>*</Text>
            </Text>
            <TextInput
              style={[styles.input, styles.textArea]}
              placeholder="Type your message or enquiry here..."
              placeholderTextColor="#8F9B9D"
              multiline
              numberOfLines={4}
              textAlignVertical="top"
              value={message}
              onChangeText={setMessage}
            />
          </View>

          {/* Submit Button */}
          <TouchableOpacity
            style={styles.submitBtn}
            onPress={handleSubmit}
            activeOpacity={0.8}
          >
            <Text style={styles.submitBtnText}>Submit Enquiry</Text>
          </TouchableOpacity>
        </View>

        {/* Footer */}
        <View style={styles.footer}>
          <Text style={styles.footerText}>
            © Pawsitive Pet Academy • All Rights Reserved
          </Text>
          <Text style={styles.footerSub}>
            Building stronger bonds through knowledge & care
          </Text>
        </View>
      </ScrollView>

      {/* Confirmation Modal */}
      <Modal
        visible={modalVisible}
        transparent={true}
        animationType="fade"
        onRequestClose={() => setModalVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalCard}>
            <Text style={styles.modalIcon}>🐾</Text>
            <Text style={styles.modalTitle}>Message Sent!</Text>
            <Text style={styles.modalBody}>{modalMessage}</Text>
            <TouchableOpacity style={styles.modalBtn} onPress={resetForm}>
              <Text style={styles.modalBtnText}>Done</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#E8F4F8', // Soft Light Blue
  },
  header: {
    backgroundColor: '#007A78', // Teal Green
    paddingTop: 50,
    paddingBottom: 18,
    paddingHorizontal: 20,
    alignItems: 'center',
    borderBottomLeftRadius: 24,
    borderBottomRightRadius: 24,
  },
  logoBadge: {
    width: 68,
    height: 68,
    borderRadius: 34,
    backgroundColor: '#FFFFFF',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 8,
    elevation: 3,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15,
    shadowRadius: 4,
  },
  logoImage: {
    width: 54,
    height: 54,
    borderRadius: 27,
  },
  brandTitle: {
    color: '#FFFFFF',
    fontSize: 15,
    fontWeight: 'bold',
    letterSpacing: 1,
  },
  tagline: {
    color: '#E8F4F8',
    fontSize: 11,
    fontWeight: '500',
    marginTop: 2,
  },
  scrollContent: {
    padding: 16,
    paddingBottom: 36,
  },
  titleSection: {
    marginVertical: 12,
  },
  mainTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#1A252C', // Deep Charcoal
  },
  subtitle: {
    fontSize: 13,
    color: '#4A5B66',
    marginTop: 4,
    lineHeight: 18,
  },
  infoRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  infoCard: {
    flex: 0.48,
    backgroundColor: '#FFFFFF',
    padding: 12,
    borderRadius: 12,
    alignItems: 'center',
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.08,
    shadowRadius: 3,
  },
  infoIcon: {
    fontSize: 20,
    marginBottom: 4,
  },
  infoTitle: {
    fontSize: 12,
    fontWeight: 'bold',
    color: '#007A78',
  },
  infoValue: {
    fontSize: 11,
    color: '#1A252C',
    marginTop: 2,
    textAlign: 'center',
  },
  formCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 18,
    elevation: 3,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 6,
  },
  formHeader: {
    fontSize: 17,
    fontWeight: 'bold',
    color: '#1A252C',
    marginBottom: 14,
  },
  inputGroup: {
    marginBottom: 14,
  },
  label: {
    fontSize: 12,
    fontWeight: '600',
    color: '#1A252C',
    marginBottom: 6,
  },
  required: {
    color: '#D9534F',
  },
  input: {
    backgroundColor: '#F4F8FA',
    borderWidth: 1,
    borderColor: '#C3D8DF',
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 10,
    fontSize: 14,
    color: '#1A252C',
  },
  textArea: {
    height: 90,
  },
  pillScrollView: {
    flexDirection: 'row',
  },
  pill: {
    backgroundColor: '#E8F4F8',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
    marginRight: 8,
    borderWidth: 1,
    borderColor: '#007A78',
  },
  pillActive: {
    backgroundColor: '#007A78',
  },
  pillText: {
    fontSize: 11,
    color: '#007A78',
    fontWeight: '600',
  },
  pillTextActive: {
    color: '#FFFFFF',
  },
  submitBtn: {
    backgroundColor: '#007A78',
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 6,
  },
  submitBtnText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: 'bold',
  },
  footer: {
    marginTop: 20,
    alignItems: 'center',
  },
  footerText: {
    fontSize: 11,
    color: '#7A8C99',
  },
  footerSub: {
    fontSize: 10,
    color: '#E5A93C', // Gold accent
    fontWeight: 'bold',
    marginTop: 2,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(26, 37, 44, 0.6)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  modalCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 24,
    alignItems: 'center',
    width: '100%',
    maxWidth: 320,
  },
  modalIcon: {
    fontSize: 36,
    marginBottom: 8,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#007A78',
    marginBottom: 8,
  },
  modalBody: {
    fontSize: 13,
    color: '#1A252C',
    textAlign: 'center',
    marginBottom: 18,
    lineHeight: 18,
  },
  modalBtn: {
    backgroundColor: '#007A78',
    paddingHorizontal: 28,
    paddingVertical: 10,
    borderRadius: 8,
  },
  modalBtnText: {
    color: '#FFFFFF',
    fontWeight: 'bold',
    fontSize: 14,
  },
});
 