import React, { useState } from 'react';
import { Text, View, StyleSheet, TouchableOpacity, SafeAreaView } from 'react-native';

export default function App() {
  // Simple state navigation simulation for previewing screens in Expo Snack
  const [currentScreen, setCurrentScreen] = useState('Home');

  // Render the requested Home Screen
  if (currentScreen === 'Home') {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.header}>
          {/* Company Name Header */}
          <Text style={styles.companyName}>Pawsitive Pet Academy</Text>
          <Text style={styles.tagline}>Training pets and owners since 2023</Text>
        </View>

        {/* Navigation Button Grid */}
        <View style={styles.buttonContainer}>
          <TouchableOpacity 
            style={styles.navButton} 
            onPress={() => setCurrentScreen('Courses')}
          >
            <Text style={styles.buttonText}>Explore Courses</Text>
          </TouchableOpacity>

          <TouchableOpacity 
            style={styles.navButton} 
            onPress={() => setCurrentScreen('Enroll')}
          >
            <Text style={styles.buttonText}>Enroll Now</Text>
          </TouchableOpacity>

          <TouchableOpacity 
            style={styles.navButton} 
            onPress={() => setCurrentScreen('Fees')}
          >
            <Text style={styles.buttonText}>Tuition & Fees</Text>
          </TouchableOpacity>

          <TouchableOpacity 
            style={styles.navButton} 
            onPress={() => setCurrentScreen('Contact')}
          >
            <Text style={styles.buttonText}>Contact Us</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  // Fallback Screen Mockup for active button simulation
  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.innerContainer}>
        <Text style={styles.screenTitle}>{currentScreen} Screen</Text>
        <Text style={styles.screenSubtitle}>Content for {currentScreen.toLowerCase()} goes here.</Text>
        <TouchableOpacity style={[styles.navButton, styles.backButton]} onPress={() => setCurrentScreen('Home')}>
          <Text style={styles.buttonText}>Back to Home</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#078B88',
  },
  innerContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },
  header: {
    flex: 2,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 20,
  },
  companyName: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#ffffff',
    textAlign: 'center',
    letterSpacing: 0.5,
  },
  tagline: {
    fontSize: 16,
    color: '#0B2947',
    marginTop: 8,
  },
  buttonContainer: {
    flex: 3,
    paddingHorizontal: 24,
    justifyContent: 'flex-start',
  },
  navButton: {
    backgroundColor: '#D9A32E',
    paddingVertical: 16,
    borderRadius: 8,
    alignItems: 'center',
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  backButton: {
    backgroundColor: '#4a5568',
    width: '100%',
    marginTop: 24,
  },
  buttonText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: '600',
  },
  screenTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#2d3748',
  },
  screenSubtitle: {
    fontSize: 14,
    color: '#718096',
    marginTop: 10,
    textAlign: 'center',
  },
});
